﻿using Microsoft.EntityFrameworkCore;
using Steam.Data;
using Steam.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Steam.Core
{
    public class GamesController
    {

        private readonly SteamDbContext _context;

        public GamesController(SteamDbContext context)
        {
            _context = context;
        }



        public void AddGame(string title, string description, string developer, string publisher, int rating, int genreId, double price)
        {
            if (string.IsNullOrEmpty(title)) throw new ArgumentException("Title cannot be null or empty.");
            if (string.IsNullOrEmpty(description)) throw new ArgumentException("Description cannot be null or empty.");
            if (string.IsNullOrEmpty(developer)) throw new ArgumentException("Developer cannot be null or empty.");
            if (string.IsNullOrEmpty(publisher)) throw new ArgumentException("Publisher cannot be null or empty.");
            if (rating < 0 || rating > 100) throw new ArgumentException("Rating must be between 0 and 100.");

            var genre = _context.Genres.Find(genreId);
            if (genre == null) throw new ArgumentException("Genre not found.");

            var game = new Games
            {
                Title = title,
                Description = description,
                Developer = developer,
                Publisher = publisher,
                Rating = rating,
                genreId = genreId,
                Genre = genre,
                Price = price
            };

            try
            {
                _context.Games.Add(game);
                _context.SaveChanges();
                Console.WriteLine("Successfully added game!");
            }
            catch (Exception ex)
            {
                throw new Exception("An error occurred while adding the game.", ex);
            }
        }

        public void UpdateGame(int gameId, string newTitle, string newDescription, string newDeveloper, string newPublisher, int newRating, int newGenreId, double price)
        {
            var game = _context.Games.Find(gameId);
            if (game == null) throw new ArgumentException("Game not found.");

            if (string.IsNullOrEmpty(newTitle)) throw new ArgumentException("Title cannot be null or empty.");
            if (string.IsNullOrEmpty(newDescription)) throw new ArgumentException("Description cannot be null or empty.");
            if (string.IsNullOrEmpty(newDeveloper)) throw new ArgumentException("Developer cannot be null or empty.");
            if (string.IsNullOrEmpty(newPublisher)) throw new ArgumentException("Publisher cannot be null or empty.");
            if (newRating < 0 || newRating > 100) throw new ArgumentException("Rating must be between 0 and 100.");

            var genre = _context.Genres.Find(newGenreId);
            if (genre == null) throw new ArgumentException("Genre not found.");

            game.Title = newTitle;
            game.Description = newDescription;
            game.Developer = newDeveloper;
            game.Publisher = newPublisher;
            game.Rating = newRating;
            game.genreId = newGenreId;
            game.Genre = genre;
            game.Price = price;

            try
            {
                _context.Games.Update(game);
                _context.SaveChanges();
                Console.WriteLine("Game updated successfully!");
            }
            catch (Exception ex)
            {
                throw new Exception("An error occurred while updating the game.", ex);
            }
        }

        public void RemoveGame(int gameId)
        {
            var game = _context.Games.Find(gameId);
            if (game == null)
            {
                Console.WriteLine("This game doesn't exist.");
                return;
            }

            try
            {
                _context.Games.Remove(game);
                _context.SaveChanges();
                Console.WriteLine("Game removed successfully!");
            }
            catch (Exception ex)
            {
                throw new Exception("An error occurred while removing the game.", ex);
            }
        }

        public void ReadGames()
        {
            var games = _context.Games.ToList();

            if (!games.Any())
            {
                Console.WriteLine("No games found.");
                return;
            }

            Console.WriteLine("=== Games ===");
            foreach (var game in games)
            {
                Console.WriteLine($"ID: {game.GameId}");
                Console.WriteLine($"Title: {game.Title}");
                Console.WriteLine($"Description: {game.Description}");
                Console.WriteLine($"Developer: {game.Developer}");
                Console.WriteLine($"Publisher: {game.Publisher}");
                Console.WriteLine($"Rating: {game.Rating}");
                Console.WriteLine($"Genre: {game.Genre?.Name}");
                Console.WriteLine($"Price: {game.Price}");
                Console.WriteLine("----------------------------");
            }
        }

        public List<Games> GetAllGames()
        {
            return _context.Games.Include(g => g.Genre).ToList();
        }

    }

}
