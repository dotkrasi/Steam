﻿using Azure;
using Microsoft.Identity.Client;
using Steam.Data;
using Steam.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Steam.Core
{
    public class UsersController
    {

        private readonly SteamDbContext _context;

        public UsersController(SteamDbContext context)
        {
            _context = context;
        }

        public void AddUser(string name, string email, string password, double balane/*, List<UserGames> games*/)
        {

            if (string.IsNullOrEmpty(name))
            {
                throw new ArgumentException("Username cannot be null or empty.");
            }
            if (string.IsNullOrEmpty(email))
            {
                throw new ArgumentException("Email cannot be null or empty.");
            }
            if (string.IsNullOrEmpty(password))
            {
                throw new ArgumentException("Password cannot be null or empty.");
            }
            if (balane < 0)
            {
                throw new ArgumentException("Balance cannot be negative.");
            }


            var user = new Users
            {
                Username = name,
                Email = email,
                Password = password,
                Balance = balane/*,
                Library = games*/
            };

            try
            {
                _context.Users.Add(user);
                _context.SaveChanges();
                Console.WriteLine("Successfully added user!");
            }
            catch (Exception ex)
            {
                throw new Exception("An error occurred while adding the user.", ex);
            }
        }

        public void UpdateUser(int userid, string newName, string newEmail, string newPassword, double newBalane/*, List<UserGames> newgames*/)
        {
            var user = _context.Users.Find(userid);
            if (user == null)
            {
                throw new ArgumentException("User not found.");
            }
            if (string.IsNullOrEmpty(newName))
            {
                throw new ArgumentException("Username cannot be null or empty.");
            }
            if (string.IsNullOrEmpty(newEmail))
            {
                throw new ArgumentException("Email cannot be null or empty.");
            }
            if (string.IsNullOrEmpty(newPassword))
            {
                throw new ArgumentException("Password cannot be null or empty.");
            }
            if (newBalane < 0)
            {
                throw new ArgumentException("GamesLibrary cannot be null or empty.");
            }


            user.Username = newName;
            user.Email = newEmail;
            user.Password = newPassword;
            user.Balance = newBalane;
            /*            user.Library = newgames;
            */


            try
            {
                _context.Users.Update(user);
                _context.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception("An error occurred while updating the user.", ex);
            }
        }

        public void DeleteUser(int userId)
        {
            var user = _context.Users.Find(userId);
            if (user == null)
            {
                Console.WriteLine("This user doesn't exist.");
                return;
            }

            try
            {
                _context.Users.Remove(user);
                _context.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception("An error occurred while updating the user.", ex);
            }
        }

        /*public string ReadUser(int userId)
        {
            var user = _context.Users.Find(userId);

            if (user == null)
                return "User not found";

            return $"ID: {user.UserId}, Username: {user.Username}, Email: {user.Email}, Balance: {user.Balance}";
        }*/
        public List<Users> GetAllUsers()
        {
            return _context.Users.ToList();
        }

    }
}
