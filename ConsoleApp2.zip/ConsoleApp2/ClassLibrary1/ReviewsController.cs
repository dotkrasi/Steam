﻿using Steam.Data;
using Steam.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Steam.Core
{
    public class ReviewsController
    {

        private readonly SteamDbContext _context;

        public ReviewsController(SteamDbContext context)
        {
            _context = context;
        }


        public void AddReview(string description, string rating, DateTime dateTime)
        {
            var review = new Reviews
            {
                Description = description,
                Rating = int.Parse(rating),
                dateTime = dateTime
            };

            try
            {
                _context.Reviews.Add(review);
                _context.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception("An error occurred while adding the review.", ex);
            }
        }

        public void UpdateReview(int reviewId, string newdescription, int newrating, DateTime newdateTime)
        {
            var review = _context.Reviews.Find(reviewId);



            review.Description = newdescription;
            review.Rating = newrating;
            review.dateTime = newdateTime;

            try
            {
                _context.Reviews.Update(review);
                _context.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception("An error occurred while updating the review.", ex);
            }
        }

        public void RemoveReview(int reviewId)
        {
            var review = _context.Reviews.Find(reviewId);

            try
            {
                _context.Reviews.Remove(review);
                _context.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception("An error occurred while updating the review.", ex);
            }

        }

        public void ReadReview(int reviewId)
        {
            var review = _context.Reviews.FirstOrDefault(r => r.ReviewId == reviewId);

            if (review == null)
            {
                Console.WriteLine("Review not found.");
                return;
            }

            Console.WriteLine("=== Review ===");
            Console.WriteLine($"ID: {review.ReviewId}");
            Console.WriteLine($"Description: {review.Description}");
            Console.WriteLine($"Rating: {review.Rating}");
            Console.WriteLine($"Date: {review.dateTime}");
        }


    }
}
