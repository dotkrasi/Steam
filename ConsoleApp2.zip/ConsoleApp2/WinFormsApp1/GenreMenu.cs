﻿using Steam.Data.Models;
using Steam.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Steam.Core;

namespace WinFormsApp1
{
    public partial class GenreMenu : Form
    {
        public GenreMenu()
        {
            InitializeComponent();
            label1.Hide();
            label2.Hide();
            textBoxGenreId.Hide();
            textBoxGenreName.Hide();
            button5.Hide();
            button6.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            try
            {
                using (var db = new SteamDbContext())
                {
                    string filePath = "genres.txt"; // или "Resources/genres.txt"
                    if (!File.Exists(filePath))
                    {
                        MessageBox.Show("Файлът genres.txt не е намерен!");
                        return;
                    }

                    var lines = File.ReadAllLines(filePath);

                    foreach (var line in lines)
                    {
                        var genre = new Genres
                        {
                            Name = line.Trim()
                        };

                        if (!db.Genres.Any(g => g.Name == genre.Name))
                        {
                            db.Genres.Add(genre);
                        }

                    }

                    db.SaveChanges();
                    MessageBox.Show("Жанровете бяха успешно добавени!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Възникна грешка: " + ex.Message);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(textBoxGenreId.Text) || string.IsNullOrWhiteSpace(textBoxGenreName.Text))
                {
                    MessageBox.Show("Моля, попълнете Genre ID и ново име.");
                    return;
                }

                int genreId = int.Parse(textBoxGenreId.Text);
                string newName = textBoxGenreName.Text.Trim();

                using (var db = new SteamDbContext())
                {
                    var genresController = new GenresController(db);
                    genresController.UpdateGenre(genreId, newName);
                }

                MessageBox.Show("Genre updated successfully!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Възникна грешка при ъпдейт на жанра: " + ex.Message);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                listBoxGenres.Items.Clear(); // изчистваме старите данни

                using (var db = new SteamDbContext())
                {
                    var genresController = new GenresController(db);
                    var genres = db.Genres.ToList(); // извличаме жанровете директно

                    foreach (var genre in genres)
                    {
                        listBoxGenres.Items.Add($"ID: {genre.GenreId} | Name: {genre.Name}");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Грешка при извличане на жанровете: " + ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            label1.Show();
            label2.Show();
            textBoxGenreId.Show();
            textBoxGenreName.Show();
            button6.Hide();
            button5.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            label1.Show();
            textBoxGenreId.Show();
            label2.Hide();
            textBoxGenreName.Hide();
            button5.Hide();
            button6.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(textBoxGenreId.Text))
                {
                    MessageBox.Show("Моля въведете ID на жанра!");
                    return;
                }

                int genreId;
                if (!int.TryParse(textBoxGenreId.Text, out genreId))
                {
                    MessageBox.Show("ID-то трябва да е число!");
                    return;
                }

                using (var db = new SteamDbContext())
                {
                    var genreController = new GenresController(db);
                    genreController.RemoveGenre(genreId);
                }

                MessageBox.Show("Жанрът беше премахнат успешно!");
                textBoxGenreId.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Възникна грешка при премахването: " + ex.Message);
            }
        }
    }
}
