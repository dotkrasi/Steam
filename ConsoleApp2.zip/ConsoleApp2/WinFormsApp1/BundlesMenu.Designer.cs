﻿namespace WinFormsApp1
{
    partial class BundlesMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button4 = new Button();
            button3 = new Button();
            button2 = new Button();
            button1 = new Button();
            listBox1 = new ListBox();
            button5 = new Button();
            textBoxBundleId = new TextBox();
            textBoxBundlePrice = new TextBox();
            textBoxBundleName = new TextBox();
            textBoxGameIds = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            button6 = new Button();
            SuspendLayout();
            // 
            // button4
            // 
            button4.Location = new Point(69, 223);
            button4.Margin = new Padding(3, 2, 3, 2);
            button4.Name = "button4";
            button4.Size = new Size(84, 53);
            button4.TabIndex = 7;
            button4.Text = "Read Bundles";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // button3
            // 
            button3.Location = new Point(69, 166);
            button3.Margin = new Padding(3, 2, 3, 2);
            button3.Name = "button3";
            button3.Size = new Size(84, 53);
            button3.TabIndex = 6;
            button3.Text = "Remove Bundles";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button2
            // 
            button2.Location = new Point(69, 109);
            button2.Margin = new Padding(3, 2, 3, 2);
            button2.Name = "button2";
            button2.Size = new Size(84, 53);
            button2.TabIndex = 5;
            button2.Text = "Update Bundles";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.Location = new Point(69, 52);
            button1.Margin = new Padding(3, 2, 3, 2);
            button1.Name = "button1";
            button1.Size = new Size(84, 53);
            button1.TabIndex = 4;
            button1.Text = "Add Bundles";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 15;
            listBox1.Location = new Point(251, 12);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(375, 154);
            listBox1.TabIndex = 8;
            // 
            // button5
            // 
            button5.Location = new Point(383, 269);
            button5.Name = "button5";
            button5.Size = new Size(75, 25);
            button5.TabIndex = 9;
            button5.Text = "Update";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // textBoxBundleId
            // 
            textBoxBundleId.Location = new Point(298, 182);
            textBoxBundleId.Name = "textBoxBundleId";
            textBoxBundleId.Size = new Size(109, 23);
            textBoxBundleId.TabIndex = 10;
            // 
            // textBoxBundlePrice
            // 
            textBoxBundlePrice.Location = new Point(298, 240);
            textBoxBundlePrice.Name = "textBoxBundlePrice";
            textBoxBundlePrice.Size = new Size(109, 23);
            textBoxBundlePrice.TabIndex = 11;
            // 
            // textBoxBundleName
            // 
            textBoxBundleName.Location = new Point(298, 211);
            textBoxBundleName.Name = "textBoxBundleName";
            textBoxBundleName.Size = new Size(109, 23);
            textBoxBundleName.TabIndex = 12;
            // 
            // textBoxGameIds
            // 
            textBoxGameIds.Location = new Point(504, 182);
            textBoxGameIds.Name = "textBoxGameIds";
            textBoxGameIds.Size = new Size(109, 23);
            textBoxGameIds.TabIndex = 13;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(231, 190);
            label1.Name = "label1";
            label1.Size = new Size(61, 15);
            label1.TabIndex = 14;
            label1.Text = "Bundle ID:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(250, 219);
            label2.Name = "label2";
            label2.Size = new Size(42, 15);
            label2.TabIndex = 15;
            label2.Text = "Name:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(256, 248);
            label3.Name = "label3";
            label3.Size = new Size(36, 15);
            label3.TabIndex = 16;
            label3.Text = "Price:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(444, 190);
            label4.Name = "label4";
            label4.Size = new Size(54, 15);
            label4.TabIndex = 17;
            label4.Text = "Game Id:";
            // 
            // button6
            // 
            button6.Location = new Point(383, 301);
            button6.Name = "button6";
            button6.Size = new Size(75, 25);
            button6.TabIndex = 18;
            button6.Text = "Remove";
            button6.UseVisualStyleBackColor = true;
            button6.Click += button6_Click;
            // 
            // BundlesMenu
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(150, 120, 240);
            ClientSize = new Size(700, 338);
            Controls.Add(button6);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(textBoxGameIds);
            Controls.Add(textBoxBundleName);
            Controls.Add(textBoxBundlePrice);
            Controls.Add(textBoxBundleId);
            Controls.Add(button5);
            Controls.Add(listBox1);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Margin = new Padding(3, 2, 3, 2);
            Name = "BundlesMenu";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "BundlesMenu";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button4;
        private Button button3;
        private Button button2;
        private Button button1;
        private ListBox listBox1;
        private Button button5;
        private TextBox textBoxBundleId;
        private TextBox textBoxBundlePrice;
        private TextBox textBoxBundleName;
        private TextBox textBoxGameIds;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Button button6;
    }
}