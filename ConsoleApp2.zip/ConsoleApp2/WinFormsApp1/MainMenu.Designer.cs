﻿namespace WinFormsApp1
{
    partial class MainMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            GenreMenu = new Button();
            ReviewMenu = new Button();
            BundleMenu = new Button();
            UserMenu = new Button();
            label1 = new Label();
            GameMenu = new Button();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            label2 = new Label();
            label3 = new Label();
            button1 = new Button();
            textBox3 = new TextBox();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            SuspendLayout();
            // 
            // GenreMenu
            // 
            GenreMenu.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            GenreMenu.Location = new Point(762, 163);
            GenreMenu.Margin = new Padding(3, 2, 3, 2);
            GenreMenu.Name = "GenreMenu";
            GenreMenu.Size = new Size(109, 58);
            GenreMenu.TabIndex = 19;
            GenreMenu.Text = "Genre Menu";
            GenreMenu.UseVisualStyleBackColor = true;
            GenreMenu.Click += GenreMenu_Click;
            // 
            // ReviewMenu
            // 
            ReviewMenu.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            ReviewMenu.Location = new Point(762, 274);
            ReviewMenu.Margin = new Padding(3, 2, 3, 2);
            ReviewMenu.Name = "ReviewMenu";
            ReviewMenu.Size = new Size(109, 58);
            ReviewMenu.TabIndex = 18;
            ReviewMenu.Text = "Review Menu";
            ReviewMenu.UseVisualStyleBackColor = true;
            ReviewMenu.Click += ReviewMenu_Click;
            // 
            // BundleMenu
            // 
            BundleMenu.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            BundleMenu.Location = new Point(219, 274);
            BundleMenu.Margin = new Padding(3, 2, 3, 2);
            BundleMenu.Name = "BundleMenu";
            BundleMenu.Size = new Size(109, 58);
            BundleMenu.TabIndex = 17;
            BundleMenu.Text = "Bundle Menu";
            BundleMenu.UseVisualStyleBackColor = true;
            BundleMenu.Click += BundleMenu_Click;
            // 
            // UserMenu
            // 
            UserMenu.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            UserMenu.Location = new Point(498, 94);
            UserMenu.Margin = new Padding(3, 2, 3, 2);
            UserMenu.Name = "UserMenu";
            UserMenu.Size = new Size(109, 58);
            UserMenu.TabIndex = 16;
            UserMenu.Text = "User Menu";
            UserMenu.UseVisualStyleBackColor = true;
            UserMenu.Click += UserMenu_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Yu Gothic", 30F, FontStyle.Bold);
            label1.Location = new Point(462, 19);
            label1.Name = "label1";
            label1.Size = new Size(146, 52);
            label1.TabIndex = 15;
            label1.Text = "Steam";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // GameMenu
            // 
            GameMenu.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            GameMenu.Location = new Point(219, 163);
            GameMenu.Margin = new Padding(3, 2, 3, 2);
            GameMenu.Name = "GameMenu";
            GameMenu.Size = new Size(109, 58);
            GameMenu.TabIndex = 14;
            GameMenu.Text = "Game Menu";
            GameMenu.UseVisualStyleBackColor = true;
            GameMenu.Click += GameMenu_Click;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(937, 19);
            textBox1.Margin = new Padding(3, 2, 3, 2);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(110, 23);
            textBox1.TabIndex = 21;
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(937, 51);
            textBox2.Margin = new Padding(3, 2, 3, 2);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(110, 23);
            textBox2.TabIndex = 22;
            textBox2.TextChanged += textBox2_TextChanged;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(864, 24);
            label2.Name = "label2";
            label2.Size = new Size(62, 15);
            label2.TabIndex = 23;
            label2.Text = "username:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(874, 56);
            label3.Name = "label3";
            label3.Size = new Size(51, 15);
            label3.TabIndex = 24;
            label3.Text = "balance:";
            // 
            // button1
            // 
            button1.Location = new Point(864, 77);
            button1.Margin = new Padding(3, 2, 3, 2);
            button1.Name = "button1";
            button1.Size = new Size(82, 22);
            button1.TabIndex = 26;
            button1.Text = "add funds:";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(951, 77);
            textBox3.Margin = new Padding(3, 2, 3, 2);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(43, 23);
            textBox3.TabIndex = 27;
            // 
            // button2
            // 
            button2.Location = new Point(1, 1);
            button2.Name = "button2";
            button2.Size = new Size(75, 23);
            button2.TabIndex = 28;
            button2.Text = "Store";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Location = new Point(1, 30);
            button3.Name = "button3";
            button3.Size = new Size(75, 23);
            button3.TabIndex = 29;
            button3.Text = "Library";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.Location = new Point(1, 59);
            button4.Name = "button4";
            button4.Size = new Size(75, 23);
            button4.TabIndex = 30;
            button4.Text = "Bundles";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // MainMenu
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(150, 120, 240);
            ClientSize = new Size(1070, 478);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(textBox3);
            Controls.Add(button1);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(GenreMenu);
            Controls.Add(ReviewMenu);
            Controls.Add(BundleMenu);
            Controls.Add(UserMenu);
            Controls.Add(label1);
            Controls.Add(GameMenu);
            ForeColor = SystemColors.ActiveCaptionText;
            Margin = new Padding(3, 2, 3, 2);
            Name = "MainMenu";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form2";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button GenreMenu;
        private Button ReviewMenu;
        private Button BundleMenu;
        private Button UserMenu;
        private Label label1;
        private Button GameMenu;
        private TextBox textBox1;
        private TextBox textBox2;
        private Label label2;
        private Label label3;
        private Button button1;
        private TextBox textBox3;
        private Button button2;
        private Button button3;
        private Button button4;
    }
}