﻿namespace WinFormsApp1
{
    partial class GenreMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            button4 = new Button();
            button3 = new Button();
            button2 = new Button();
            listBoxGenres = new ListBox();
            textBoxGenreId = new TextBox();
            textBoxGenreName = new TextBox();
            label1 = new Label();
            label2 = new Label();
            button5 = new Button();
            button6 = new Button();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(57, 49);
            button1.Margin = new Padding(3, 2, 3, 2);
            button1.Name = "button1";
            button1.Size = new Size(95, 56);
            button1.TabIndex = 0;
            button1.Text = "Add genres";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button4
            // 
            button4.Location = new Point(57, 229);
            button4.Margin = new Padding(3, 2, 3, 2);
            button4.Name = "button4";
            button4.Size = new Size(95, 56);
            button4.TabIndex = 7;
            button4.Text = "Read Genre";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // button3
            // 
            button3.Location = new Point(57, 169);
            button3.Margin = new Padding(3, 2, 3, 2);
            button3.Name = "button3";
            button3.Size = new Size(95, 56);
            button3.TabIndex = 6;
            button3.Text = "Remove Genre";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button2
            // 
            button2.Location = new Point(57, 109);
            button2.Margin = new Padding(3, 2, 3, 2);
            button2.Name = "button2";
            button2.Size = new Size(95, 56);
            button2.TabIndex = 5;
            button2.Text = "Update Genre";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // listBoxGenres
            // 
            listBoxGenres.FormattingEnabled = true;
            listBoxGenres.ItemHeight = 15;
            listBoxGenres.Location = new Point(261, 12);
            listBoxGenres.Name = "listBoxGenres";
            listBoxGenres.Size = new Size(251, 139);
            listBoxGenres.TabIndex = 8;
            // 
            // textBoxGenreId
            // 
            textBoxGenreId.Location = new Point(343, 169);
            textBoxGenreId.Name = "textBoxGenreId";
            textBoxGenreId.Size = new Size(71, 23);
            textBoxGenreId.TabIndex = 9;
            // 
            // textBoxGenreName
            // 
            textBoxGenreName.Location = new Point(343, 202);
            textBoxGenreName.Name = "textBoxGenreName";
            textBoxGenreName.Size = new Size(71, 23);
            textBoxGenreName.TabIndex = 10;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(316, 177);
            label1.Name = "label1";
            label1.Size = new Size(21, 15);
            label1.TabIndex = 11;
            label1.Text = "ID:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(296, 210);
            label2.Name = "label2";
            label2.Size = new Size(41, 15);
            label2.TabIndex = 12;
            label2.Text = "Genre:";
            // 
            // button5
            // 
            button5.Location = new Point(343, 262);
            button5.Name = "button5";
            button5.Size = new Size(71, 23);
            button5.TabIndex = 13;
            button5.Text = "Update";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // button6
            // 
            button6.Location = new Point(343, 262);
            button6.Name = "button6";
            button6.Size = new Size(71, 23);
            button6.TabIndex = 14;
            button6.Text = "Remove";
            button6.UseVisualStyleBackColor = true;
            button6.Click += button6_Click;
            // 
            // GenreMenu
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(150, 120, 240);
            ClientSize = new Size(700, 338);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(textBoxGenreName);
            Controls.Add(textBoxGenreId);
            Controls.Add(listBoxGenres);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Margin = new Padding(3, 2, 3, 2);
            Name = "GenreMenu";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "GenreMenu";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Button button4;
        private Button button3;
        private Button button2;
        private ListBox listBoxGenres;
        private TextBox textBoxGenreId;
        private TextBox textBoxGenreName;
        private Label label1;
        private Label label2;
        private Button button5;
        private Button button6;
    }
}