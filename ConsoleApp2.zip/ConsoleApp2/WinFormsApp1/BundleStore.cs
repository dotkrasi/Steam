﻿using Steam.Core;
using Steam.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class BundleStore : Form
    {
        private readonly SteamDbContext _context;
        private readonly Queries _queries;
        private readonly int _userId;

        public BundleStore(int userId)
        {
            InitializeComponent();
            _context = new SteamDbContext();
            _queries = new Queries(_context);
            _userId = userId;
        }

        
    }
}
