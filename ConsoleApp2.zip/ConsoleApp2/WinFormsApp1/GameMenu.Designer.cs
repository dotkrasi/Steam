﻿namespace WinFormsApp1
{
    partial class GameMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            button2 = new Button();
            listBoxLibrary = new ListBox();
            button3 = new Button();
            button5 = new Button();
            textBoxGameId = new TextBox();
            textBoxTitle = new TextBox();
            textBoxDescription = new TextBox();
            textBoxDeveloper = new TextBox();
            textBoxPublisher = new TextBox();
            textBoxRating = new TextBox();
            buttonUpdateGame = new Button();
            textBoxGenreId = new TextBox();
            textBoxPrice = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            button4 = new Button();
            SuspendLayout();
            // 
            // button1
            // 
            button1.BackColor = SystemColors.Control;
            button1.Location = new Point(66, 92);
            button1.Margin = new Padding(3, 2, 3, 2);
            button1.Name = "button1";
            button1.Size = new Size(92, 46);
            button1.TabIndex = 0;
            button1.Text = "Add Games";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(66, 245);
            button2.Margin = new Padding(3, 2, 3, 2);
            button2.Name = "button2";
            button2.Size = new Size(92, 46);
            button2.TabIndex = 1;
            button2.Text = "Show all games ";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // listBoxLibrary
            // 
            listBoxLibrary.FormattingEnabled = true;
            listBoxLibrary.ItemHeight = 15;
            listBoxLibrary.Location = new Point(223, 19);
            listBoxLibrary.Margin = new Padding(3, 2, 3, 2);
            listBoxLibrary.Name = "listBoxLibrary";
            listBoxLibrary.Size = new Size(559, 184);
            listBoxLibrary.TabIndex = 2;
            listBoxLibrary.SelectedIndexChanged += listBoxLibrary_SelectedIndexChanged;
            // 
            // button3
            // 
            button3.Location = new Point(66, 194);
            button3.Margin = new Padding(3, 2, 3, 2);
            button3.Name = "button3";
            button3.Size = new Size(92, 46);
            button3.TabIndex = 6;
            button3.Text = "Remove Games";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button5
            // 
            button5.Location = new Point(66, 143);
            button5.Margin = new Padding(3, 2, 3, 2);
            button5.Name = "button5";
            button5.Size = new Size(92, 46);
            button5.TabIndex = 5;
            button5.Text = "Update Games";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // textBoxGameId
            // 
            textBoxGameId.Location = new Point(305, 234);
            textBoxGameId.Margin = new Padding(3, 2, 3, 2);
            textBoxGameId.Name = "textBoxGameId";
            textBoxGameId.Size = new Size(110, 23);
            textBoxGameId.TabIndex = 7;
            // 
            // textBoxTitle
            // 
            textBoxTitle.Location = new Point(305, 259);
            textBoxTitle.Margin = new Padding(3, 2, 3, 2);
            textBoxTitle.Name = "textBoxTitle";
            textBoxTitle.Size = new Size(110, 23);
            textBoxTitle.TabIndex = 8;
            // 
            // textBoxDescription
            // 
            textBoxDescription.Location = new Point(305, 284);
            textBoxDescription.Margin = new Padding(3, 2, 3, 2);
            textBoxDescription.Name = "textBoxDescription";
            textBoxDescription.Size = new Size(110, 23);
            textBoxDescription.TabIndex = 9;
            // 
            // textBoxDeveloper
            // 
            textBoxDeveloper.Location = new Point(305, 308);
            textBoxDeveloper.Margin = new Padding(3, 2, 3, 2);
            textBoxDeveloper.Name = "textBoxDeveloper";
            textBoxDeveloper.Size = new Size(110, 23);
            textBoxDeveloper.TabIndex = 10;
            // 
            // textBoxPublisher
            // 
            textBoxPublisher.Location = new Point(590, 234);
            textBoxPublisher.Margin = new Padding(3, 2, 3, 2);
            textBoxPublisher.Name = "textBoxPublisher";
            textBoxPublisher.Size = new Size(110, 23);
            textBoxPublisher.TabIndex = 11;
            // 
            // textBoxRating
            // 
            textBoxRating.Location = new Point(590, 259);
            textBoxRating.Margin = new Padding(3, 2, 3, 2);
            textBoxRating.Name = "textBoxRating";
            textBoxRating.Size = new Size(110, 23);
            textBoxRating.TabIndex = 12;
            // 
            // buttonUpdateGame
            // 
            buttonUpdateGame.Location = new Point(466, 332);
            buttonUpdateGame.Margin = new Padding(3, 2, 3, 2);
            buttonUpdateGame.Name = "buttonUpdateGame";
            buttonUpdateGame.Size = new Size(82, 22);
            buttonUpdateGame.TabIndex = 13;
            buttonUpdateGame.Text = "Update";
            buttonUpdateGame.UseVisualStyleBackColor = true;
            buttonUpdateGame.Click += buttonUpdateGame_Click;
            // 
            // textBoxGenreId
            // 
            textBoxGenreId.Location = new Point(590, 284);
            textBoxGenreId.Margin = new Padding(3, 2, 3, 2);
            textBoxGenreId.Name = "textBoxGenreId";
            textBoxGenreId.Size = new Size(110, 23);
            textBoxGenreId.TabIndex = 14;
            // 
            // textBoxPrice
            // 
            textBoxPrice.Location = new Point(590, 308);
            textBoxPrice.Margin = new Padding(3, 2, 3, 2);
            textBoxPrice.Name = "textBoxPrice";
            textBoxPrice.Size = new Size(110, 23);
            textBoxPrice.TabIndex = 15;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(276, 239);
            label1.Name = "label1";
            label1.Size = new Size(21, 15);
            label1.TabIndex = 16;
            label1.Text = "ID:";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(264, 264);
            label2.Name = "label2";
            label2.Size = new Size(33, 15);
            label2.TabIndex = 17;
            label2.Text = "Title:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(223, 289);
            label3.Name = "label3";
            label3.Size = new Size(70, 15);
            label3.TabIndex = 18;
            label3.Text = "Description:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(229, 314);
            label4.Name = "label4";
            label4.Size = new Size(63, 15);
            label4.TabIndex = 19;
            label4.Text = "Developer:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(522, 236);
            label5.Name = "label5";
            label5.Size = new Size(59, 15);
            label5.TabIndex = 20;
            label5.Text = "Publisher:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(536, 264);
            label6.Name = "label6";
            label6.Size = new Size(44, 15);
            label6.TabIndex = 21;
            label6.Text = "Rating:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(528, 289);
            label7.Name = "label7";
            label7.Size = new Size(51, 15);
            label7.TabIndex = 22;
            label7.Text = "GenreId:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(546, 314);
            label8.Name = "label8";
            label8.Size = new Size(36, 15);
            label8.TabIndex = 23;
            label8.Text = "Price:";
            // 
            // button4
            // 
            button4.Location = new Point(466, 332);
            button4.Name = "button4";
            button4.Size = new Size(82, 23);
            button4.TabIndex = 24;
            button4.Text = "Remove";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // GameMenu
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(150, 120, 240);
            ClientSize = new Size(822, 406);
            Controls.Add(button4);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(textBoxPrice);
            Controls.Add(textBoxGenreId);
            Controls.Add(buttonUpdateGame);
            Controls.Add(textBoxRating);
            Controls.Add(textBoxPublisher);
            Controls.Add(textBoxDeveloper);
            Controls.Add(textBoxDescription);
            Controls.Add(textBoxTitle);
            Controls.Add(textBoxGameId);
            Controls.Add(button3);
            Controls.Add(button5);
            Controls.Add(listBoxLibrary);
            Controls.Add(button2);
            Controls.Add(button1);
            Margin = new Padding(3, 2, 3, 2);
            Name = "GameMenu";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "GameMenu";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Button button2;
        private ListBox listBoxLibrary;
        private Button button3;
        private Button button5;
        private TextBox textBoxGameId;
        private TextBox textBoxTitle;
        private TextBox textBoxDescription;
        private TextBox textBoxDeveloper;
        private TextBox textBoxPublisher;
        private TextBox textBoxRating;
        private Button buttonUpdateGame;
        private TextBox textBoxGenreId;
        private TextBox textBoxPrice;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Button button4;
    }
}