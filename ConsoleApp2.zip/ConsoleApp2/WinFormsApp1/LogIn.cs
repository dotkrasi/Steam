﻿using Steam.Data;
using Steam.Data.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class LogIn : Form
    {
        public LogIn()
        {
            InitializeComponent();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            Register form1 = new Register();
            form1.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            string username = textBoxUsername.Text;
            string password = textBoxPassword.Text;

            using (var db = new SteamDbContext())
            {
                var user = db.Users.FirstOrDefault(u => u.Username == username && u.Password == password);

                if (user == null)
                {
                    MessageBox.Show("Invalid username or password!");
                    return;
                }

                MessageBox.Show($"Welcome, {user.Username}! Your balance: {user.Balance} $");

                // Пример: можеш да пазиш логнатия user като глобална променлива
                Session.CurrentUser = user;
            }

            this.Close(); // затваря Login формата
            MainMenu mainMenu = new MainMenu();
            mainMenu.ShowDialog();
        }
    }
}
