﻿namespace WinFormsApp1
{
    partial class Register
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            linkLabel1 = new LinkLabel();
            password = new Label();
            username = new Label();
            PasswordTxT = new TextBox();
            UsernameTxT = new TextBox();
            label1 = new Label();
            retype = new Label();
            RetypeTxT = new TextBox();
            button1 = new Button();
            SuspendLayout();
            // 
            // linkLabel1
            // 
            linkLabel1.AutoSize = true;
            linkLabel1.Location = new Point(137, 527);
            linkLabel1.Name = "linkLabel1";
            linkLabel1.Size = new Size(240, 20);
            linkLabel1.TabIndex = 19;
            linkLabel1.TabStop = true;
            linkLabel1.Text = "Log in if you don't have an account";
            linkLabel1.LinkClicked += linkLabel1_LinkClicked;
            // 
            // password
            // 
            password.AutoSize = true;
            password.Font = new Font("Segoe UI Semibold", 15F, FontStyle.Bold);
            password.Location = new Point(133, 236);
            password.Name = "password";
            password.Size = new Size(128, 35);
            password.TabIndex = 18;
            password.Text = "Password:";
            // 
            // username
            // 
            username.AutoSize = true;
            username.Font = new Font("Segoe UI Semibold", 15F, FontStyle.Bold);
            username.Location = new Point(126, 156);
            username.Name = "username";
            username.Size = new Size(135, 35);
            username.TabIndex = 17;
            username.Text = "Username:";
            // 
            // PasswordTxT
            // 
            PasswordTxT.Font = new Font("Segoe UI", 15F);
            PasswordTxT.Location = new Point(264, 230);
            PasswordTxT.Name = "PasswordTxT";
            PasswordTxT.Size = new Size(223, 41);
            PasswordTxT.TabIndex = 16;
            // 
            // UsernameTxT
            // 
            UsernameTxT.Font = new Font("Segoe UI", 15F);
            UsernameTxT.Location = new Point(264, 150);
            UsernameTxT.Name = "UsernameTxT";
            UsernameTxT.Size = new Size(223, 41);
            UsernameTxT.TabIndex = 15;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 28.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(173, 13);
            label1.Name = "label1";
            label1.Size = new Size(195, 62);
            label1.TabIndex = 14;
            label1.Text = "Register";
            // 
            // retype
            // 
            retype.AutoSize = true;
            retype.Font = new Font("Segoe UI Semibold", 15F, FontStyle.Bold);
            retype.Location = new Point(41, 311);
            retype.Name = "retype";
            retype.Size = new Size(223, 35);
            retype.TabIndex = 21;
            retype.Text = "Re-type Password:";
            // 
            // RetypeTxT
            // 
            RetypeTxT.Font = new Font("Segoe UI", 15F);
            RetypeTxT.Location = new Point(264, 308);
            RetypeTxT.Name = "RetypeTxT";
            RetypeTxT.Size = new Size(223, 41);
            RetypeTxT.TabIndex = 20;
            // 
            // button1
            // 
            button1.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(393, 391);
            button1.Name = "button1";
            button1.Size = new Size(94, 29);
            button1.TabIndex = 22;
            button1.Text = "Continue";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // Register
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(150, 120, 240);
            ClientSize = new Size(550, 564);
            Controls.Add(button1);
            Controls.Add(retype);
            Controls.Add(RetypeTxT);
            Controls.Add(linkLabel1);
            Controls.Add(password);
            Controls.Add(username);
            Controls.Add(PasswordTxT);
            Controls.Add(UsernameTxT);
            Controls.Add(label1);
            Name = "Register";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Register";
            Load += Register_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private LinkLabel linkLabel1;
        private Label password;
        private Label username;
        private TextBox PasswordTxT;
        private TextBox UsernameTxT;
        private Label label1;
        private Label retype;
        private TextBox RetypeTxT;
        private Button button1;
    }
}