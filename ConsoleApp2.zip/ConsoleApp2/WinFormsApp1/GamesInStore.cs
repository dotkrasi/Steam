﻿using Steam.Core;
using Steam.Data;
using Steam.Data.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class GamesInStore : Form
    {
        private readonly SteamDbContext _context;
        private readonly int _userId;
        public GamesInStore(int userId)
        {
            InitializeComponent();
            _userId = userId;
            _context = new SteamDbContext();

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void GamesInStore_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            /*    int userId = Session.CurrentUser.UserId;
                var library = _queries.GetUserLibrary(userId);
    */
            var allGames = _context.Games
               .OrderBy(g => g.Title)
               .ToList();

            if (!allGames.Any())
            {
                listBox1.Items.Add("No games found.");
                return;
            }
            foreach (var game in allGames)
            {
                listBox1.Items.Add($"{game.Title} ({game.Genre}) - Price: {game.Price}$");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (Session.CurrentUser == null)
                {
                    MessageBox.Show("No user is logged in!");
                    return;
                }

                string gameTitle = textBox1.Text.Trim();

                using (var db = new SteamDbContext())
                {
                    var query = new Queries(db);
                    query.BuyGame(Session.CurrentUser.UserId, gameTitle);

                    // Обновяваме баланса в Session-а, за да е актуален
                    Session.CurrentUser = db.Users.Find(Session.CurrentUser.UserId);
                }

                MessageBox.Show("Game purchased successfully!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
    }
}
